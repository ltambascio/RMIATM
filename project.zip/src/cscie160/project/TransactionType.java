package cscie160.project;

/**
 * Transaction type enumerator type.
 * 
 * @author	Larry Tambascio
 * @version	1.0
 */
public enum TransactionType
{
	DEPOSIT, WITHDRAW, BALANCE
}
